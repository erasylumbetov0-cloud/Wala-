# Megapolis — Vercel-ready static website

## Deploy to Vercel
1. Upload this folder to a GitHub repository.
2. In Vercel choose **Add New → Project** and import the repository.
3. Framework Preset: **Other**. Build Command: leave empty. Output Directory: `.`.
4. Click **Deploy**.

## House numbers
`residents.json` contains all residents. The current provisional mapping sets each house number equal to the resident list number. To change a house, edit the `house` value for that resident and redeploy.
